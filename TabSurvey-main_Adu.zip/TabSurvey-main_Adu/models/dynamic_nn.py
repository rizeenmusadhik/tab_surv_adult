# models/dynamic_net_model.py

import os
import shutil
import logging
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.tensorboard import SummaryWriter
from sklearn.preprocessing import LabelEncoder
import pandas as pd
import numpy as np


# Import BaseModelTorch to inherit common PyTorch functionality
from models.basemodel_torch import BaseModelTorch

# Import your external model components (make sure these paths are correct)
from models.dynamic_net_lib import dynamic_net, fully_connected

class DynamicNetModel(BaseModelTorch):
    """
    Integrated DynamicNet model.

    This model builds a backbone using a fully connected network and wraps it in a dynamic_net.
    It uses the number of features and classes from the input arguments (like SAINT) and integrates
    with the repository's training and hyperparameter optimization pipelines.
    """
    def __init__(self, params, args):
        super().__init__(params, args)
        self.args = args

        # Use the input arguments to set up model dimensions:
        # Use args.num_features as input dimension and args.num_classes for the output dimension.
        nIn = args.num_features  # Total number of features provided via the config
        nOut = getattr(args, 'nOut', 5)  # Intermediate output dimension (default 5; adjust if needed)
        nBlocks = getattr(args, 'nBlocks', 3)
        num_classes = args.num_classes  # Should be provided by the config

        # Log categorical info if available (for debugging/information)
        if hasattr(args, 'cat_idx') and args.cat_idx:
            logging.info("Using categorical indices: %s with dimensions: %s", args.cat_idx, args.cat_dims)
        else:
            logging.info("No categorical indices provided; using all features as continuous.")

        # Build the backbone using the fully_connected model
        self.backbone = fully_connected(nIn, nOut, nBlocks, num_classes)
        # Build the dynamic_net model around the backbone
        print(args)
        self.model = dynamic_net(self.backbone, args)

        # Send model to device (handled by BaseModelTorch)
        self.to_device()

    def fit(self, X, y, X_val=None, y_val=None):
        """
        Train the model.

        The training data is provided as NumPy arrays from load_data.
        """
        os.makedirs(self.args.result_dir, exist_ok=True)
        logging.info("Training arguments: %s", self.args)
        summary_writer = SummaryWriter(os.path.join(self.args.result_dir, 'summary'))
        # Convert NumPy arrays to PyTorch tensors
        print(X.dtype)
        #X = torch.tensor(X, dtype=torch.float32)
        #y = torch.tensor(y)
        
        X = np.array(X, dtype=np.float64)
        X_val = np.array(X_val, dtype=np.float64)
        #if X_val is not None and y_val is not None:
         #   X_val = torch.tensor(X_val, dtype=torch.float32)
          #  y_val = torch.tensor(y_val)
           # val_dataset = torch.utils.data.TensorDataset(X_val, y_val)
            #val_loader = torch.utils.data.DataLoader(val_dataset,
             #                                        batch_size=self.args.val_batch_size,
              #                                       shuffle=False,
               #                                      num_workers=self.args.val_workers,
                #                                     pin_memory=True,
                 #                                    drop_last=True)
        #else:
         #   val_loader = None

        train_dataset = torch.utils.data.TensorDataset(torch.tensor(X).float(), torch.tensor(y).float())
        train_loader = torch.utils.data.DataLoader(train_dataset,
                                                   batch_size=self.args.batch_size,
                                                   shuffle=True,
                                                   #num_workers=self.args.workers,
                                                   pin_memory=True,
                                                   drop_last=True)
                                                   

        # Set up optimizer and scheduler.
        val_dataset = torch.utils.data.TensorDataset(torch.tensor(X_val).float(), torch.tensor(y_val).float())
        val_loader = torch.utils.data.DataLoader(val_dataset,
                                                   batch_size=self.args.batch_size,
                                                   shuffle=True,
                                                   #num_workers=self.args.workers,
                                                   pin_memory=True,
                                                   drop_last=True)
        nBlocks = self.args.nBlocks
        #self.args.weight_decay = list(map(float, self.args.weight_decay.split(',')))
        params_group = [{
            'params': self.model.parameters(nBlocks - 1),
            'weight_decay': self.args.weight_decay
        }]
        #all_classifiers=True
        self.optimizer = optim.SGD(params_group, lr=self.args.lr_f, momentum=self.args.momentum)
        self.scheduler = torch.optim.lr_scheduler.MultiStepLR(self.optimizer, self.args.lr_milestones, gamma=0.1)

        start_epoch = 0
        if getattr(self.args, 'resume', False):
            ckpt_path = os.path.join(self.args.result_dir, 'model_latest.pth')
            ckpt = torch.load(ckpt_path, map_location=self.device)
            start_epoch = ckpt['epoch'] + 1
            self.model.load_state_dict(ckpt['state_dict'])
            self.optimizer.load_state_dict(ckpt['optimizer'])
            self.scheduler.load_state_dict(ckpt['scheduler'])

        best_accu = -1
        for epoch in range(start_epoch, self.args.epochs):
            logging.info(f"Epoch {epoch}")
            self._train_epoch(train_loader, epoch, summary_writer)
            self.scheduler.step()

            if val_loader is not None:
                accu_val = self._evaluate(val_loader, summary_writer, epoch, prefix='val')
                accu_train = self._evaluate(train_loader, summary_writer, epoch, prefix='train')
            else:
                accu_val = [-1]

            # Save checkpoint
            checkpoint = {
                'epoch': epoch,
                'state_dict': self.model.state_dict(),
                'optimizer': self.optimizer.state_dict(),
                'scheduler': self.scheduler.state_dict(),
            }
            torch.save(checkpoint, os.path.join(self.args.result_dir, 'model_latest.pth'))
            if accu_val[-1] >= best_accu:
                best_accu = accu_val[-1]
                shutil.copyfile(os.path.join(self.args.result_dir, 'model_latest.pth'),
                                os.path.join(self.args.result_dir, 'model_best.pth'))
        return [], []  # Optionally return loss histories

    def _train_epoch(self, train_loader, epoch, summary_writer):
        #self.model.train_all() 
        self.model.module.train_all()  # Change from self.model.train_all()
 # Ensure the model is in training mode (this method should be defined in dynamic_net)
        # Choose loss function based on objective
        if self.args.objective == 'binary':
            criterion = nn.BCEWithLogitsLoss().to(self.device)
        else:
            criterion = nn.MSELoss().to(self.device)
        nBlocks = self.args.nBlocks

        for it, (x, y) in enumerate(train_loader):
            x, y = x.to(self.device), y.to(self.device)
            # Assume dynamic_net provides forward_all() that returns outputs for each block/stage.
            preds, preds_ensemble = self.model.module.forward_all(x, nBlocks - 1)
            y = y.unsqueeze(1)  # Adjust target shape for loss calculation
            preds_tensor = torch.stack(preds)

            loss = 0
            for block_idx in range(nBlocks):
                out = preds_ensemble[block_idx]
                loss += criterion(preds_tensor[block_idx - 1] + out, y)

            if it % 50 == 0:
                logging.info(f"Epoch {epoch}, Iteration {it}, Loss: {loss.item():.4f}")
                summary_writer.add_scalar('loss', loss.item(), epoch * len(train_loader) + it)

            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()

    def _evaluate(self, data_loader, summary_writer, epoch, prefix=''):
        self.model.module.eval_all()  # Ensure evaluation mode
        nBlocks = self.args.nBlocks
        corrects = [0] * nBlocks
        totals = [0] * nBlocks
        with torch.no_grad():
            for x, y in data_loader:
                x, y = x.to(self.device), y.to(self.device)
                outs = self.model.module.forward(x)
                for i, out in enumerate(outs):
                    # For binary classification, assume threshold of 0 on logits
                    corrects[i] += ((out > 0).squeeze(1) == y).sum().item()
                    totals[i] += y.shape[0]

        accuracies = [c / t * 100 if t > 0 else 0 for c, t in zip(corrects, totals)]
        for i, accu in enumerate(accuracies):
            summary_writer.add_scalar(f'{prefix}_stage_{i}_accu', accu, epoch)
        print(accuracies)    
        return accuracies

    def predict(self, X):
        """
        Predict labels for input data X (NumPy array). Returns predictions as a NumPy array.
        """
        self.model.module.eval_all()
        X_tensor = torch.tensor(X, dtype=torch.float32).to(self.device)
        with torch.no_grad():
            outs = self.model.module.forward(X_tensor)
        # Use the output of the final stage for prediction.
        predictions = (outs[-1] > 0).int().cpu().numpy()
        print('hello1')
        print(predictions)
        return predictions

    def predict_proba(self, X):
        """
        Predict probabilities for binary classification.
        """
        self.model.module.eval_all()
        X_tensor = torch.tensor(X, dtype=torch.float32).to(self.device)
        with torch.no_grad():
            logits = self.model.module.forward(X_tensor)[-1]
        probabilities = torch.sigmoid(logits).cpu().numpy()
        print('hello2')
        print(probabilities)

        return probabilities

    @classmethod
    def define_trial_parameters(cls, trial, args):
        """
        Define hyperparameter ranges for automated optimization with Optuna.
        """
        params = {}
        params['lr_f'] = trial.suggest_loguniform('lr_f', 1e-4, 1e-1)
        params['momentum'] = trial.suggest_uniform('momentum', 0.5, 0.99)
        # Add more hyperparameters as needed
        return params
